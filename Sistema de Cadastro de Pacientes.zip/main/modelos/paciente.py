
class Paciente:
    def __init__(self, nome, cpf, email, telefone, celular, data_nascimento, sexo, estado_civil ):
        self.nome = nome
        self.cpf = cpf
        self.email = email
        self.telefone = telefone
        self.celular = celular
        self.data_nascimento = data_nascimento
        self.sexo = sexo
        self.estado_civil = estado_civil
